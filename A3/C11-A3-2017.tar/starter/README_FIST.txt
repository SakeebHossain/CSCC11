NOTES:

  The labels for classes in the BBC data are in [0-4]. Your class labels
(because you're indexing in Matlab which starts at 1) will be in [1-5].

  You will have to account for this in your code! Don't forget, or else
nothing will work properly.

